# America250 Dashboard — Module Template

An interactive per-state U.S. map + detail-panel dashboard, built as a
**template**: any new dataset can be plugged in as a self-contained module
without touching the map, panel, or chart components.

Two modules ship with this template:

- **Demographics** — U.S. Census population, age, race, and migration (real data)
- **Economy** — state GDP, unemployment, trade, CPI (**sample/placeholder data**,
  included only to prove the template works for a differently-shaped dataset —
  see "Sample data" below)

## Quick start

```bash
npm install
npm run dev
```

## How it works

```
src/
  modules/
    registry.js        # <- the ONLY file you edit to add/remove a module
    demographics.js     # module config (reference example, real data)
    economy.js           # module config (sample data, second example)
  components/            # generic, domain-agnostic — a module's config
                          # tells these what to render, they don't know
                          # anything about "population" or "GDP"
    USMap.jsx
    StatePanel.jsx
    TimeSeriesChart.jsx
    FlowCompare.jsx
    BarBreakdown.jsx
    CategoryBreakdown.jsx
    StateRanking.jsx
    TrendChart.jsx
    SummaryCards.jsx
    ModuleTabs.jsx
    PeriodScrubber.jsx   # optional, opt-in
  App.jsx                 # renders whichever module is active, driven
                            # entirely by its config
```

A **module** is a plain JS object describing one dataset: where its JSON
lives, which field colors the map, what shows in the state detail panel,
and (optionally) national summary cards, a sortable ranking table, and a
multi-state trend chart. Nothing else in the codebase needs to change.

## Adding a new module

1. **Get your per-state JSON into `public/`.**
   Shape: `{ "metadata": {...}, "states": { "<fips>": { "name", "abbr", "fips", ...your fields } } }`.
   Every state record must have `name`, `abbr`, and `fips` — everything else is yours to define.

2. **Copy `src/modules/economy.js`** as your starting point and edit:
   - `id`, `label`, `icon`, `dataUrl`, `title`, `subtitle`, `source`
   - `mapMetric` — which field colors the choropleth
   - `summary(states)` — optional national stat cards
   - `panel` — what shows in the right-hand panel when a state is clicked:
     - `hero` / `badge` / `rankBadge` / `quickStats`
     - `sections`: an ordered list, each one of:
       - `type: 'timeseries'` → line/area chart over time (`getSeries` returns `{period: value}`)
       - `type: 'flow'` → signed bars + net total (`getRows` returns `[{label, value}]`)
       - `type: 'bars'` → horizontal share-of-total bars (`getGroups`, `getTotal`)
       - `type: 'categories'` → colored-dot category list (`getGroups` with `color`, `getTotal`)
   - `views` — which extra views to expose (`'map'`, `'ranking'`, `'trend'`)
   - `ranking.columns` / `trend` — config for those optional views

3. **Register it** in `src/modules/registry.js`:
   ```js
   import yourModule from './yourModule.js'
   const modules = [demographics, economy, yourModule]
   ```

That's it — a new tab appears automatically, with map, panel, and (if configured) ranking/trend views.

## Verifying a module

`verify_modules.mjs` runs every accessor function in every registered module
against its real JSON data (all states, not just one) and reports any field
that throws or returns a non-finite number — useful for catching typos in
`getValue`/`getSeries`/etc. before you open a browser:

```bash
npm run verify
```

## Sample data

`public/economy.json` is **synthetic placeholder data**, generated to have a
realistic shape (not fetched from any real source) purely to demonstrate a
second module. `metadata.sample_data: true` marks this in the file itself.
To make it real, use `scripts/download_economy.py` and `scripts/clean_economy.py`
(already in this project) to pull actual BLS/BEA figures, then update
`extract_data.py`-style logic to shape it into `{states: {...}}` and point
`economy.js`'s `dataUrl` at the result.

## Available scripts

| Script | Purpose |
|---|---|
| `npm run dev` | Local dev server with HMR |
| `npm run build` | Production build to `dist/` |
| `npm run preview` | Serve the production build locally |
| `npm run lint` | Oxlint |
| `npm run verify` | Runtime-check every module's accessors against real data |
